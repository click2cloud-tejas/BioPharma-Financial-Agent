document.getElementById("send-btn").onclick = sendMessage;

function sendMessage() {
    const input = document.getElementById("user-input");
    const text = input.value.trim();
    if (!text) return;

    appendMessage("user", text);
    input.value = "";

    fetch("/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: text })
    })
    .then(res => res.json())
    .then(data => {
        console.log("DEBUG:", data);  // <---- ADD THIS LINE
        appendMessage("bot", data.answer);
    });
}

function appendMessage(sender, message) {
    const chatBox = document.getElementById("chat-box");

    const div = document.createElement("div");
    div.className = sender === "user" ? "chat-user" : "chat-bot";
    div.innerHTML = `<b>${sender === "user" ? "You" : "AI"}:</b> ${message}`;

    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
}
