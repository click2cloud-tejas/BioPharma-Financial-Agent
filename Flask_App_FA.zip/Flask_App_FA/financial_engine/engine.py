import os
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from openai import AzureOpenAI
from dotenv import load_dotenv
import json

load_dotenv()

# -----------------------------
# Azure OpenAI Configuration
# -----------------------------
AZURE_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01")
MODEL_NAME = os.getenv("AZURE_OPENAI_MODEL", "gpt-4o-mini")

client = AzureOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    api_key=AZURE_API_KEY,
    api_version=AZURE_API_VERSION
)

# -----------------------------
# Load Excel data
# -----------------------------
EXCEL_PATH = Path(r"D:\BioPharma_Tejas\Codes_new\Financial_data_example_english_col_renamed.xlsx")
df = pd.read_excel(EXCEL_PATH)
df.columns = df.columns.str.lower()

financial_metrics = sorted(df["metrics"].dropna().unique().tolist())
companies = sorted(df["company"].dropna().unique().tolist())
periods = sorted(df["date_str"].dropna().unique().tolist())

# (ALL YOUR FUNCTIONS HERE, UNCHANGED)
# extract_query_understanding(...)
# filter_financial_data(...)
# dataframe_to_sentence_list(...)
# generate_financial_answer(...)
# ask_for_insights(...)
# create_visualization(...)
def extract_query_understanding(user_query):
    prompt = f"""
You are a STRICT financial information extraction engine.

Your job is to extract ALL relevant entities from the user query.

Return results ONLY from the provided lists:

METRICS = {financial_metrics}
COMPANIES = {companies}
PERIODS = {periods}

=====================================
### METRIC MATCHING
=====================================
• Extract ALL metrics mentioned.
• Map synonyms (sales → domestic sales, laba → profit, etc.).
If User tell last year then consider the year as 2021

=====================================
### COMPANY MATCHING
=====================================
• Extract ALL companies mentioned.
• Partial matching allowed:
  “bio farma”, “pt biofarma”, “biofarma” → match “PT Bio Farma Tbk”.

=====================================
### PERIOD MATCHING
=====================================
• Extract ALL periods mentioned (month + year).
• Match to closest period in PERIODS list.

=====================================
### COMPARISON DETECTION
=====================================
Set is_comparison = true if query contains:
compare, vs, versus, difference, growth, trend, increase, decrease.

=====================================
### INSIGHTS DETECTION
=====================================
Set ask_insights = true if query contains:
explain, why, insight, reason, analysis, elaborate.

=====================================
### OUTPUT FORMAT
=====================================
Return ONLY JSON. Example:

{{
  "metrics": ["Net Profit", "Sales"],
  "companies": ["PT Bio Farma Tbk", "PT Kimia Farma Tbk"],
  "periods": ["January 2021"],
  "is_comparison": true,
  "ask_insights": false
}}

=====================================

User query: "{user_query}"
"""

    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[{"role": "user", "content": prompt}]
    )

    try:
        parsed = json.loads(response.choices[0].message.content)
    except:
        parsed = {"metrics": [], "companies": [], "periods": [], "is_comparison": False, "ask_insights": False}

    return parsed


# ----------------------------------------------------------
# STEP 2 — Filter dataset (supports MULTI filters)
# ----------------------------------------------------------
def filter_financial_data(parsed):
    metrics = parsed.get("metrics", [])
    companies = parsed.get("companies", [])
    periods = parsed.get("periods", [])

    temp = df.copy()

    if metrics:
        temp = temp[temp["metrics"].str.lower().isin([m.lower() for m in metrics])]

    if companies:
        temp = temp[temp["company"].str.lower().isin([c.lower() for c in companies])]

    # if periods:
    #     temp = temp[temp["date_str"].astype(str).str.lower().isin([str(p).lower() for p in periods])]

    return temp


# ----------------------------------------------------------
# STEP 3 — Convert DF → JSON-like text for LLM
# ----------------------------------------------------------
def dataframe_to_sentence_list(filtered_df):
    records = []

    for _, row in filtered_df.iterrows():
        rec = {
            "company": row["company"],
            "period": str(row["date_str"]),
            "metric": row["metrics"],
            "realization_budget": row["realization_budget"],
            "planning_budget": row["planning_budget"],
            "unit": row.get("column_format", "")
        }
        records.append(rec)

    json_lines = [json.dumps(r, ensure_ascii=False) for r in records]
    return "\n".join(json_lines)


# ----------------------------------------------------------
# STEP 4 — Generate Final Answer
# ----------------------------------------------------------
def generate_financial_answer(user_query, filtered_df):
    structured_text = dataframe_to_sentence_list(filtered_df)

#     prompt = f"""
# You are a financial analyst. Your answers MUST be short, simple, and focused.

# ===============================
# CRITICAL NUMBER RULES
# ===============================
# 1. You MUST reproduce numbers EXACTLY as they appear in the data.
#    - DO NOT abbreviate (11700.65 → 11.7 or 11.70 ❌)
#    - DO NOT convert scales (11700 → 11.7 ❌)
#    - DO NOT round (11700.65 → 11701 ❌)
#    - DO NOT add or remove commas (11700.65 stays 11700.65)
#    - DO NOT convert formats (23065.26 → 23.07 ❌)

# 2. When giving a number:
#    - Copy the value EXACTLY from **realization_budget** and add billions
#    - NEVER apply ANY mathematical transformation
#    - NEVER divide, multiply, or scale the values
#    - NEVER infer units — use the unit exactly as in the data

# 3. ALWAYS assume the number already includes the correct currency unit.

# ===============================
# ANSWERING RULES
# ===============================
# 1. ALWAYS use realization_budget as the primary value.
# 2. Keep answers SHORT unless user requests details.
# 3. ONLY give planning_budget if user requests comparison or insights.
# 4. If multiple companies or metrics exist, return a SHORT comparison.
# 5. Provide insights ONLY if user asks “why”, “explain”, “insight”, etc.
# 6. Never invent numbers. Use only the provided structured data.
# 7. ALWAYS include the currency unit (e.g., billion).


# ===============================
# STRUCTURED EXCEL DATA
# ===============================
# {structured_text}

# ===============================
# USER QUESTION
# ===============================
# {user_query}

# Give a concise, accurate answer.
# """
    



    prompt = f"""

You are a financial analyst. Your answers MUST be short, simple, and focused.

===============================
CRITICAL NUMBER RULES
===============================
1. You MUST reproduce numbers EXACTLY as they appear in the data.
   - DO NOT abbreviate (11700.65 → 11.7 or 11.70 ❌)
   - DO NOT convert scales (11700 → 11.7 ❌)
   - DO NOT round (11700.65 → 11701 ❌)
   - DO NOT add or remove commas (11700.65 stays 11700.65)
   - DO NOT convert formats (23065.26 → 23.07 ❌)

2. When giving a number:
   - Copy the value EXACTLY from **realization_budget** and add billions
   - NEVER apply ANY mathematical transformation
   - NEVER divide, multiply, or scale the values
   

3. ALWAYS assume the number already includes the correct currency unit.
Your answers MUST be:
- EXTREMELY SHORT (1–2 sentences only)
- NO LISTS
- NO BULLET POINTS
- NO MONTH-BY-MONTH VALUES
- NO DETAILED BREAKDOWN
- NO MULTI-LINE OUTPUT
- NO ENUMERATION
- ONLY give one short summary sentence.

===============================
STRICT ANSWER FORMAT RULES
===============================
1. Never list each month separately.
2. Never print the entire dataset.
3. Never write more than 2 sentences.
4. If comparison is requested, give only a HIGH-LEVEL comparison.
5. ALWAYS give only the final comparison, not raw values.
6. Do NOT explain. Just answer.
7. Do NOT include extra details unless user explicitly asks “show details”.

===============================
STRUCTURED EXCEL DATA
===============================
{structured_text}

===============================
USER QUESTION
===============================
{user_query}

===============================
FINAL REQUIREMENT
===============================
Provide ONLY a short 1–2 sentence answer. Nothing else.
"""


    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content


# ----------------------------------------------------------
# STEP 5 — Visualization
# ----------------------------------------------------------
def create_visualization(filtered_df, metric, company):
    if filtered_df.empty:
        print("No data to visualize.")
        return

    plt.figure(figsize=(8, 5))
    plt.plot(filtered_df["date_str"], filtered_df["realization_budget"], label="Realization Budget")
    plt.plot(filtered_df["date_str"], filtered_df["planning_budget"], label="Planning Budget")

    plt.xlabel("Period")
    plt.ylabel("Budget")
    plt.title(f"{metric} – {company}")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("comparison_plot.png")

    print("Visualization saved as comparison_plot.png")


# ----------------------------------------------------------
# STEP 6 — Insights follow-up
# ----------------------------------------------------------
def ask_for_insights():
    print("\n🔍 Additional insight question:")
    print("How does this value compare with the realization and planned budget?")


def process_financial_query(user_query):
    """This function will be called from Flask."""
    parsed = extract_query_understanding(user_query)
    filtered = filter_financial_data(parsed)
    final_answer = generate_financial_answer(user_query, filtered)

    return {
        "llm_understanding": parsed,
        "filtered_data": filtered.to_dict(orient="records"),
        "final_answer": final_answer
    }
