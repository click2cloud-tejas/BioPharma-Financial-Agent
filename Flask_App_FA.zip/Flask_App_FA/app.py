from flask import Flask, render_template, request, jsonify
from financial_engine.engine import process_financial_query
from dotenv import load_dotenv
load_dotenv()

app = Flask(__name__, static_folder="static")

import math

def clean_json(obj):
    """Recursively convert NaN → None to make valid JSON."""
    if isinstance(obj, dict):
        return {k: clean_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_json(item) for item in obj]
    elif isinstance(obj, float) and math.isnan(obj):
        return None
    return obj

# ✅ ADD THIS ROUTE
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    data = request.json
    user_query = data.get("query")

    result = process_financial_query(user_query)
    cleaned = clean_json(result["filtered_data"])

    return jsonify({
        "answer": result["final_answer"],
        "understanding": result["llm_understanding"],
        "filtered": cleaned
    })

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5003)
